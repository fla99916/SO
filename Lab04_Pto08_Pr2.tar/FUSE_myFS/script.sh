#!/bin/bash
MPOINT="./mount-point"

echo -e "/nCrea el directorio temp /n"
rm -R -f temp
mkdir temp

echo -e "/nCopia los ficheros a nuestro SF y al temp /n"
cp ./src/fuseLib.c ./src/myFS.h $MPOINT/
cp ./src/fuseLib.c ./src/myFS.h ./temp

echo -e "/nRealizando el diff del fuseLib.c y el myFS.h entre el original y el de SF /n"
./my-fsck virtual-disk
diff ./src/fuseLib.c $MPOINT/fuseLib.c
diff ./src/myFS.h $MPOINT/myFS.h

echo -e "/nTruncando el fuseLib.c fichero en copiasTemporales y en nuesto SF /n"
truncate -s 14899 ./temp/fuseLib.c
truncate -s 14899 $MPOINT/fuseLib.c

echo -e "/nRealizando el diff del fuseLib.c entre el original y el truncado/n"
./my-fsck virtual-disk
diff ./src/fuseLib.c ./temp/fuseLib.c
diff ./src/fuseLib.c $MPOINT/fuseLib.c

echo -e "/nCopiando el fuseLib.h al SF/n"
cp ./src/fuseLib.h $MPOINT/

echo -e "/nDiff del fuseLib.h entre el fichero original y el copiado en el SF/n"
./my-fsck virtual-disk
diff ./src/fuseLib.h $MPOINT/fuseLib.h

echo -e "/nTruncando el myFS.h en copiasTemporales y en nuesto SF /n"
truncate -s 11395 ./temp/myFS.h
truncate -s 11395 $MPOINT/myFS.h

echo -e "/nRealizando el diff del myFS.h entre el original y el truncado/n"
./my-fsck virtual-disk
diff ./src/myFS.h $MPOINT/myFS.h
diff ./src/myFS.h ./temp/myFS.h







