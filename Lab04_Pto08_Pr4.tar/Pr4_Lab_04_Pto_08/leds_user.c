#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>

void ledsFunction(int leds);

static const char* cnt_str[9] = {
"1",
"2",
"3",
"1",
"23",
"12",
"3",
"2",
"1"
};

int main(){
	int leds = open("/dev/leds", O_WRONLY | O_CREAT | O_TRUNC);

	ledsFunction(leds);
	
	close(leds);
	return 0;

}

void ledsFunction(int leds){
	int i = 0;



	for(i = 0; i < 9; i++){
		write(leds, cnt_str[i],strlen(cnt_str[i]));
		sleep(2);
	}

}





