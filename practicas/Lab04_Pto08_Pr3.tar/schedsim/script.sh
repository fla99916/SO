#!/bin/bash
i=1
fichero=""

if(rm -r result)
then
	echo "Borramos la carpeta result "
fi
mkdir result
echo "Creamos la carpeta result"


echo "Introduzca el fichero (ej:examples/example*.txt) "
read fichero

while [ ! -e "$fichero" ]
do
	echo "El fichero no encontrado"	
	echo "Introduzca el fichero (ej:examples/example*.txt) "
	read fichero
done

echo "Introduzca el vaor máximo para CPU"
read maxCPUs

while [ $maxCPUs -lt 1 ] || [ $maxCPUs -gt 8 ]
do
	echo "Introduzca el vaor máximo para CPU entre 1 y 8"
	read maxCPUs
done


for i in $maxCPUs
do
	echo "el número de CPU = $i"

	echo "Creando logs del RR "
	./schedsim -i $fichero -n $i -s RR
	
	j=1
	while [ $j -le $i ]
	do
		echo "Moviendo los logs a la carpeta result "
		mv CPU_$j.log ./result/RR_CPU_$j.log
		echo "Generando gráficas.. "
		cd ../gantt-gplot
		./generate_gantt_chart ../schedsim/result/RR_CPU_$j.log
		cd ../schedsim
		((j++))
	done

	
###################################################################
	echo "Creando logs del SJF "
	./schedsim -i $fichero -n $i -s SJF
	
	j=1
	while [ $j -le $i ]
	do
		echo "Moviendo los logs a la carpeta result "
		mv CPU_$j.log ./result/SJF_CPU_$j.log
		echo "Generando gráficas.. "
		cd ../gantt-gplot
		./generate_gantt_chart ../schedsim/result/SJF_CPU_$j.log
		cd ../schedsim
		((j++))
	done
###################################################################
	cd ../schedsim
	echo "Creando logs del FCFS"
	./schedsim -i $fichero -n $i -s FCFS
	
	j=1
	while [ $j -le $i ]
	do
		echo "Moviendo los logs a la carpeta result "
		mv CPU_$j.log ./result/FCFS_CPU_$j.log
		echo "Generando gráficas.. "
		cd ../gantt-gplot
		./generate_gantt_chart ../schedsim/result/FCFS_CPU_$j.log
		cd ../schedsim
		((j++))
	done
###################################################################
	cd ../schedsim
	echo "Creando logs del PRIOR "
	./schedsim -i $fichero -n $i -s PRIOR
	
	j=1
	while [ $j -le $i ]
	do
		echo "Moviendo los logs a la carpeta result "
		mv CPU_$j.log ./result/PRIOR_CPU_$j.log
		echo "Generando gráficas.. "
		cd ../gantt-gplot
		./generate_gantt_chart ../schedsim/result/PRIOR_CPU_$j.log
		cd ../schedsim
		((j++))
	done
done
